obs           = obslua
host_name_source	= "Host Name"
host_title_source	= "Host Title"
host_contact1_source	= "Host Contact 1"
host_contact2_source	= "Host Contact 2"

guest_name_source	= "Guest Name"
guest_title_source	= "Guest Title"
guest_contact1_source	= "Guest Contact 1"
guest_contact2_source	= "Guest Contact 2"

stat_1_source	= "Stat 1"
stat_2_source	= "Stat 2"
stat_3_source	= "Stat 3"
stat_4_source	= "Stat 4"
slide_show_source = "Slide Show"

border_color_source	= "Border Color"
fill_color_source	= "Fill Color"
background_image_source	= "Background Image"
background_animation_source	= "Background Animation"
title_music_source	= "Music"

function host_name()
	local text = host_name_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(host_name_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function host_title()
	local text = host_title_text
	
	local color = secondary_text_color
	
	local font = secondary_font
		
	local source = obs.obs_get_source_by_name(host_title_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function host_contact1()
	local text = host_contact1_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(host_contact1_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function host_contact2()
	local text = host_contact2_text
	
	local color = secondary_text_color
	
	local font = secondary_font
		
	local source = obs.obs_get_source_by_name(host_contact2_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function guest_name()
	local text = guest_name_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(guest_name_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function guest_title()
	local text = guest_title_text
	
	local color = secondary_text_color
	
	local font = secondary_font
		
	local source = obs.obs_get_source_by_name(guest_title_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function guest_contact1()
	local text = guest_contact1_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(guest_contact1_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function guest_contact2()
	local text = guest_contact2_text
	
	local color = secondary_text_color
	
	local font = secondary_font
		
	local source = obs.obs_get_source_by_name(guest_contact2_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function stat_1()
	local text = stat_1_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(stat_1_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function stat_2()
	local text = stat_2_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(stat_2_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function stat_3()
	local text = stat_3_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(stat_3_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function stat_4()
	local text = stat_4_text
	
	local color = primary_text_color
	
	local font = primary_font
		
	local source = obs.obs_get_source_by_name(stat_4_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "text", text)
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_data_set_obj(settings, "font", font)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function graphics()
	local files = slide_show
		
	local source = obs.obs_get_source_by_name(slide_show_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_array(settings, "files", files)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function border()
	local color = border_color
		
	local source = obs.obs_get_source_by_name(border_color_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function fill()
	local color = fill_color
		
	local source = obs.obs_get_source_by_name(fill_color_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_int(settings, "color", color)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function background1()
	local file = background_image
		
	local source = obs.obs_get_source_by_name(background_image_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "file", file)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
end

function background2()
	local file = background_animation
	
	local source = obs.obs_get_source_by_name(background_animation_source)
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "local_file", file)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end
	
	if toggle_background == true then
			obs.obs_source_set_enabled(source, false)
			else
			obs.obs_source_set_enabled(source, true)
		end
	
end

function music()
	local file = title_music
		
	local source = obs.obs_get_source_by_name(title_music_source)
	
	if source ~= nil then
			local settings = obs.obs_data_create()
			obs.obs_data_set_string(settings, "local_file", file)
			obs.obs_source_update(source, settings)
			obs.obs_data_release(settings)
			obs.obs_source_release(source)
		end

	if loop_music == true then
			local settings = obs.obs_data_create()
			obs.obs_data_set_bool(settings, "looping", true)
			obs.obs_source_update(source, settings)

			else
			local settings = obs.obs_data_create()
			obs.obs_data_set_bool(settings, "looping", false)
			obs.obs_source_update(source, settings)			

		end
	
	if toggle_music == true then
			obs.obs_source_set_enabled(source, false)
			else
			obs.obs_source_set_enabled(source, true)
		end
end

function reset(pressed)
	
	if not pressed then
		return
	end

	host_name()
	host_title()
	host_contact1()
	host_contact2()
	guest_name()
	guest_title()
	guest_contact1()
	guest_contact2()
	stat_1()
	stat_2()
	stat_3()
	stat_4()
	border()
	fill()
	background1()
	background2()
	music()
	graphics()

end

function settings_modified(props, prop, settings)
	return true
end

function script_properties()
	local props = obs.obs_properties_create()
	
	obs.obs_properties_add_text(props, "host_name_text", "Host Name", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "host_title_text", "Host Title", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "host_contact1_text", "Host Contact 1", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "host_contact2_text", "Host Contact 2", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "guest_name_text", "Guest Name", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "guest_title_text", "Guest Title", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "guest_contact1_text", "Guest Contact 1", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "guest_contact2_text", "Guest Contact 2", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "stat_1_text", "Stat 1", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "stat_2_text", "Stat 2", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "stat_3_text", "Stat 3", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_text(props, "stat_4_text", "Stat 4", obs.OBS_TEXT_DEFAULT)
	obs.obs_properties_add_editable_list(props, "slide_show", "Graphics", obs.OBS_EDITABLE_LIST_TYPE_FILES, "Image Files (*.bmp *.tga *.png *.jpeg *.jpg *.gif)", "")
	obs.obs_properties_add_font(props, "primary_font", "Primary Text Font")
	obs.obs_properties_add_color(props, "primary_text_color", "Primary Text Color")
	obs.obs_properties_add_font(props, "secondary_font", "Secondary Text Font")
	obs.obs_properties_add_color(props, "secondary_text_color", "Secondary Text Color")
	obs.obs_properties_add_color(props, "border_color", "Border Color")
	obs.obs_properties_add_color(props, "fill_color", "Fill Color")
	obs.obs_properties_add_path(props, "background_image", "Background Image", obs.OBS_PATH_FILE, "Image Files (*.bmp *.tga *.png *.jpeg *.jpg *.gif *.psd)", "")
	obs.obs_properties_add_path(props, "background_animation", "Background Animation", obs.OBS_PATH_FILE, "Video Files (*.mp4 *.ts *.mov *.flv *.mkv *.avi *.gif *.webm)", "")
	obs.obs_properties_add_bool(props, "toggle_background", "Toggle Animation")
	obs.obs_properties_add_path(props, "title_music", "Title Music", obs.OBS_PATH_FILE, "Audio Files (*.mp3 *.aac *.ogg *.wav)", "")
	obs.obs_properties_add_bool(props, "loop_music", "Loop")
	obs.obs_properties_add_bool(props, "toggle_music", "Toggle Music")

	obs.obs_property_set_modified_callback(p_mode, settings_modified)

	return props
end

function script_description()
	return "Podcast Template"
end

function script_update(settings)
	
	host_name_text = obs.obs_data_get_string(settings, "host_name_text")
	host_title_text = obs.obs_data_get_string(settings, "host_title_text")
	host_contact1_text = obs.obs_data_get_string(settings, "host_contact1_text")
	host_contact2_text = obs.obs_data_get_string(settings, "host_contact2_text")
	guest_name_text = obs.obs_data_get_string(settings, "guest_name_text")
	guest_title_text = obs.obs_data_get_string(settings, "guest_title_text")
	guest_contact1_text = obs.obs_data_get_string(settings, "guest_contact1_text")
	guest_contact2_text = obs.obs_data_get_string(settings, "guest_contact2_text")
	stat_1_text = obs.obs_data_get_string(settings, "stat_1_text")
	stat_2_text = obs.obs_data_get_string(settings, "stat_2_text")
	stat_3_text = obs.obs_data_get_string(settings, "stat_3_text")
	stat_4_text = obs.obs_data_get_string(settings, "stat_4_text")
	primary_font = obs.obs_data_get_obj(settings, "primary_font")
	secondary_font = obs.obs_data_get_obj(settings, "secondary_font")
	primary_text_color = obs.obs_data_get_int(settings, "primary_text_color")
	secondary_text_color = obs.obs_data_get_int(settings, "secondary_text_color")
	border_color = obs.obs_data_get_int(settings, "border_color")
	fill_color = obs.obs_data_get_int(settings, "fill_color")
	background_image = obs.obs_data_get_string(settings, "background_image")
	background_animation = obs.obs_data_get_string(settings, "background_animation")
	toggle_background = obs.obs_data_get_bool(settings, "toggle_background")
	title_music = obs.obs_data_get_string(settings, "title_music")
	toggle_music = obs.obs_data_get_bool(settings, "toggle_music")
	loop_music = obs.obs_data_get_bool(settings, "loop_music")
	slide_show = obs.obs_data_get_array(settings, "slide_show")
	
	reset(true)
end

function script_defaults(settings)
		
end

function script_save(settings)

end

function script_load(settings)
	local sh = obs.obs_get_signal_handler()
	obs.signal_handler_connect(sh, "source_activate", source_activated)
	obs.signal_handler_connect(sh, "source_deactivate", source_deactivated)

	obs.obs_frontend_add_event_callback(on_event)
end
